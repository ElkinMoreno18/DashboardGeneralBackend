module.exports = (sequelize, Sequelize) => {
    const Test = sequelize.define("test", {
            months: {
                type: Sequelize.INTEGER
            },
            pptoVenta: {
                type: Sequelize.FLOAT,
                get() {
                    const pptoV = this.getDataValue('pptoVenta');
                    return parseFloat(pptoV);
                }
            },
            VentaEjecutada: {
                type: Sequelize.FLOAT,
                get() {
                    const ventaEjec = this.getDataValue('VentaEjecutada');
                    return parseFloat(ventaEjec);
                }
            },
            Cumplimiento: {
                type: Sequelize.DOUBLE,
                get() {
                    const VentaEjec = this.getDataValue('VentaEjecutada');
                    const pptAc = this.getDataValue('PresupuestoAcumulado');
                    if(pptAc == 0){
                        return 0;
                    } else {
                    return VentaEjec / pptAc;
                    }
                }
            },
            VentaActual: {
                type: Sequelize.FLOAT,
                get(){
                    const VentaAc = this.getDataValue('VentaActual');
                    return parseFloat(VentaAc);
                }
            },
            PorcentajeVentaActual: {
                type: Sequelize.DOUBLE
            },
            VentaNueva: {
                type: Sequelize.FLOAT,
                get() {
                    const VentaNu = this.getDataValue('VentaNueva');
                    return parseFloat(VentaNu);
                }

            },
            PorcentajeVentaNueva: {
                type: Sequelize.DOUBLE
            },
            PresupuestoAcumulado: {
                type: Sequelize.FLOAT,
                get() {
                    const pAcum = this.getDataValue('PresupuestoAcumulado');
                    return parseFloat(pAcum);
                }
            },
            ComisionAct: {
                type: Sequelize.FLOAT,
                get() {
                    const clienteFact = this.getDataValue('VentaActual');
                    const cumpl = this.getDataValue('Cumplimiento');
                    const role = this.getDataValue('rol');

                    if( role === 'vendedor') {

                    const limite1 = 50;
                    const limite2 = 60;
                    const limite3 = 70;
                    const limite4 = 80;
                    const limite5 = 90;
                    const limite6 = 100;

                    comisionActual1 = 0.004;
                    comisionActual2 = 0.005;
                    comisionActual3 = 0.006;
                    comisionActual4 = 0.006;
                    comisionActual5 = 0.006;
                    comisionActual6 = 0.006;

                    if( cumpl >= 0 && cumpl <= limite1 ) {
                        return clienteFact * comisionActual1;
                    }

                    if(cumpl >= 51 && cumpl <= limite2) {
                        return clienteFact * comisionActual2;
                    }

                    if(cumpl >= 61 && cumpl <= limite3) {
                        return clienteFact * comisionActual3;
                    }

                    if(cumpl >= 71 && cumpl <= limite4 ) {
                        return clienteFact * comisionActual4;
                    }

                    if(cumpl >= 81 && cumpl <= limite5) {
                        return clienteFact * comisionActual5;
                    }

                    if(cumpl >= 91 && cumpl <= limite6){
                        return clienteFact *  comisionActual5;
                    }

                    }

                    if( role === 'coordinador') {

                    const limite1 = 50;
                    const limite2 = 60;
                    const limite3 = 70;
                    const limite4 = 80;
                    const limite5 = 90;
                    const limite6 = 100;

                    comisionActual1 = 0.001;
                    comisionActual2 = 0.001;
                    comisionActual3 = 0.001;
                    comisionActual4 = 0.001;
                    comisionActual5 = 0.001;
                    comisionActual6 = 0.001;

                    if( cumpl >= 0 && cumpl <= limite1 ) {
                        return clienteFact * comisionActual1;
                    }

                    if(cumpl >= 51 && cumpl <= limite2) {
                        return clienteFact * comisionActual2;
                    }

                    if(cumpl >= 61 && cumpl <= limite3) {
                        return clienteFact * comisionActual3;
                    }

                    if(cumpl >= 71 && cumpl <= limite4 ) {
                        return clienteFact * comisionActual4;
                    }

                    if(cumpl >= 81 && cumpl <= limite5) {
                        return clienteFact * comisionActual5;
                    }

                    if(cumpl >= 91 && cumpl <= limite6){
                        return clienteFact *  comisionActual5;
                    }


                    }


                    if( role === 'general') {

                        const limite1 = 50;
                        const limite2 = 60;
                        const limite3 = 70;
                        const limite4 = 80;
                        const limite5 = 90;
                        const limite6 = 100;

                        comisionActual1 = 0.0040;
                        comisionActual2 = 0.0050;
                        comisionActual3 = 0.0060;
                        comisionActual4 = 0.0060;
                        comisionActual5 = 0.0060;
                        comisionActual6 = 0.0060;

                        if( cumpl >= 0 && cumpl <= limite1 ) {
                            return clienteFact * comisionActual1;
                        }

                        if(cumpl >= 51 && cumpl <= limite2) {
                            return clienteFact * comisionActual2;
                        }

                        if(cumpl >= 61 && cumpl <= limite3) {
                            return clienteFact * comisionActual3;
                        }

                        if(cumpl >= 71 && cumpl <= limite4 ) {
                            return clienteFact * comisionActual4;
                        }

                        if(cumpl >= 81 && cumpl <= limite5) {
                            return clienteFact * comisionActual5;
                        }

                        if(cumpl >= 91 && cumpl <= limite6){
                            return clienteFact *  comisionActual5;
                        }


                        }

                    return 0;
                }
            },
            ComisionNue: {
                type: Sequelize.FLOAT,
                get() {
                    const valueVentaNueva = this.getDataValue('VentaNueva');
                    const cumpl = this.getDataValue('Cumplimiento');
                    const role = this.getDataValue('rol');

                    if( role === 'vendedor') {

                    const limite1 = 50;
                    const limite2 = 60;
                    const limite3 = 70;
                    const limite4 = 80;
                    const limite5 = 90;
                    const limite6 = 100;

                    comisionNueva1 = 0.0080;
                    comisionNueva2 = 0.0093;
                    comisionNueva3 = 0.0095;
                    comisionNueva4 = 0.0096;
                    comisionNueva5 = 0.0098;
                    comisionNueva6 = 0.0098;

                    if( cumpl >= 0 && cumpl <= limite1 ) {
                        return valueVentaNueva * comisionNueva1;
                    }

                    if(cumpl >= 51 && cumpl <= limite2) {
                        return valueVentaNueva * comisionNueva2;
                    }

                    if(cumpl >= 61 && cumpl <= limite3) {
                        return valueVentaNueva * comisionNueva3;
                    }

                    if(cumpl >= 71 && cumpl <= limite4 ) {
                        return valueVentaNueva * comisionNueva4;
                    }

                    if(cumpl >= 81 && cumpl <= limite5) {
                        return valueVentaNueva * comisionNueva5;
                    }

                    if(cumpl >= 91 && cumpl <= limite6){
                        return valueVentaNueva * comisionNueva5;
                    }

                    }


                    if( role === 'coordinador') {

                        const limite1 = 50;
                        const limite2 = 60;
                        const limite3 = 70;
                        const limite4 = 80;
                        const limite5 = 90;
                        const limite6 = 100;

                        comisionNueva1 = 0.0045;
                        comisionNueva2 = 0.0045;
                        comisionNueva3 = 0.0045;
                        comisionNueva4 = 0.0045;
                        comisionNueva5 = 0.0045;
                        comisionNueva6 = 0.0045;

                        if( cumpl >= 0 && cumpl <= limite1 ) {
                            return valueVentaNueva * comisionNueva1;
                        }

                        if(cumpl >= 51 && cumpl <= limite2) {
                            return valueVentaNueva * comisionNueva2;
                        }

                        if(cumpl >= 61 && cumpl <= limite3) {
                            return valueVentaNueva * comisionNueva3;
                        }

                        if(cumpl >= 71 && cumpl <= limite4 ) {
                            return valueVentaNueva * comisionNueva4;
                        }

                        if(cumpl >= 81 && cumpl <= limite5) {
                            return valueVentaNueva * comisionNueva5;
                        }

                        if(cumpl >= 91 && cumpl <= limite6){
                            return valueVentaNueva * comisionNueva5;
                        }

                        }


                        if( role === 'general') {

                            const limite1 = 50;
                            const limite2 = 60;
                            const limite3 = 70;
                            const limite4 = 80;
                            const limite5 = 90;
                            const limite6 = 100;

                            comisionNueva1 = 0.0080;
                            comisionNueva2 = 0.0093;
                            comisionNueva3 = 0.0095;
                            comisionNueva4 = 0.0096;
                            comisionNueva5 = 0.0098;
                            comisionNueva6 = 0.0098;

                            if( cumpl >= 0 && cumpl <= limite1 ) {
                                return valueVentaNueva * comisionNueva1;
                            }

                            if(cumpl >= 51 && cumpl <= limite2) {
                                return valueVentaNueva * comisionNueva2;
                            }

                            if(cumpl >= 61 && cumpl <= limite3) {
                                return valueVentaNueva * comisionNueva3;
                            }

                            if(cumpl >= 71 && cumpl <= limite4 ) {
                                return valueVentaNueva * comisionNueva4;
                            }

                            if(cumpl >= 81 && cumpl <= limite5) {
                                return valueVentaNueva * comisionNueva5;
                            }

                            if(cumpl >= 91 && cumpl <= limite6){
                                return valueVentaNueva * comisionNueva5;
                            }

                            }

                    return 0;

                }
            },
            salarioTotal: {
                type: Sequelize.FLOAT,
                get() {
                    const sbase = parseFloat(this.getDataValue('monthSalary'));
                    const cActual = parseFloat(this.getDataValue('ComisionAct'));
                    const cNueva = parseFloat(this.getDataValue('ComisionNue'));

                    return parseFloat(sbase +  cActual + cNueva);

                }
            },
            usuarioLogueado: {
                type: Sequelize.STRING
            },
            representante: {
                type: Sequelize.STRING
            },
            monthSalary: {
                type: Sequelize.FLOAT,
                get(){
                    const monthSal = parseFloat(this.getDataValue('monthSalary'));
                    const role = this.getDataValue('rol');

                    if(role === 'vendedor' || role === 'coordinador')
                    {
                        return parseFloat(monthSal);
                    }

                      // if(role === 'general') {
                     //    return 2050000*4)
                    // }

                    return monthSal;

                }
            },
            pptoMensual: {
                type: Sequelize.FLOAT,
                get(){
                    const pptMon = parseFloat(this.getDataValue('pptoMensual'));
                    return parseFloat(pptMon);
                }
            },
            pptoAnual: {
                type: Sequelize.FLOAT,
                get() {
                    const pptoValue = this.getDataValue('pptoAnual');
                    const rolValue =  this.getDataValue('rol');

                    if(rolValue === 'coordinador') {
                        return parseFloat(pptoValue*4);
                    }

                    if(rolValue === 'general') {
                        return parseFloat(pptoValue*4);
                    }

                    return parseFloat(pptoValue);
                }
            },
            rol: {
                type: Sequelize.STRING
            },
    });
    return Test;
};