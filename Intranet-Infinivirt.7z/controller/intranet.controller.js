

exports.login = (require, response) => {
	let username = require.body.username;
	let password = require.body.password;
	if(){

	}
}